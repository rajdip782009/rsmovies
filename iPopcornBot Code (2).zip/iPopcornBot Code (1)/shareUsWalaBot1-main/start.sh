echo "Cloning Repo...."
git clone https://github.com/RoyalKrrishna/shareUsWalaBot1.git /shareUsWalaBot1
cd /shareUsWalaBot1
pip3 install -r requirements.txt
echo "Starting Bot...."
python3 main.py
